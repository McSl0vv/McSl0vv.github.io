---
layout: page
title: Tentang saya
permalink: /about/
---

Hanya seorang anak lelaki pada umumnya, hanya saja sangat tertarik pada dunia IT

### Tujuan Blog

Di sini saya akan berbagi tentang hal-hal ataupun informasi yang saya ketahui dan semoga itu bermanfaat untuk pengunjung di sini.

### Contact me

[ikiwoioi11@gmail.com](mailto:ikiwoioi11@gmail.com)
